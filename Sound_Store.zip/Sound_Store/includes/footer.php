<footer class="footer">
    <div class="container text-center"><span class="text-muted"><b>Copyright&copy;Sound Store | All Rights Reserved | Contact Us: +91 7013827080</b></span></div>
</footer>
    